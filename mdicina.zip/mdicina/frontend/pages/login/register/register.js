// script.js
document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");

  form.addEventListener("submit", async (e) => {
    e.preventDefault(); // Evita reload da página

    // Pega os valores dos campos
    const nome = form.nome.value.trim();
    const email = form.email.value.trim();
    const senha = form.senha.value.trim();
    const tipo = form.tipo.value;

    // Validação simples
    if (!nome || !email || !senha) {
      alert("Por favor, preencha todos os campos obrigatórios!");
      return;
    }

    try {
      // Envia dados para o backend
      const response = await fetch("http://localhost:3000/api/users/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, senha, tipo }),
      });

      const data = await response.json();

      if (response.ok) {
        alert(`✅ Usuário cadastrado com sucesso! ID: ${data.id}`);
        form.reset(); // limpa o formulário
      } else {
        alert(`⚠️ Erro: ${data.error || "Não foi possível cadastrar o usuário"}`);
      }
    } catch (err) {
      console.error("Erro ao registrar usuário:", err);
      alert("❌ Erro de conexão com o servidor.");
    }
  });
});
