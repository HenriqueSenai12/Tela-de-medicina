// script.js - Cadastro e listagem de pacientes
document.addEventListener("DOMContentLoaded", async () => {
  const form = document.querySelector("form");
  const tabela = document.querySelector("tbody");

  // 🔹 Função para validar CPF
  function validarCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g, "");
    if (cpf.length !== 11) return false;
    if (/^(\d)\1{10}$/.test(cpf)) return false;

    let soma = 0;
    for (let i = 0; i < 9; i++) soma += parseInt(cpf.charAt(i)) * (10 - i);
    let resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.charAt(9))) return false;

    soma = 0;
    for (let i = 0; i < 10; i++) soma += parseInt(cpf.charAt(i)) * (11 - i);
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.charAt(10))) return false;

    return true;
  }

  // 🔹 Função para validar telefone
  function validarTelefone(telefone) {
    const apenasNumeros = telefone.replace(/[^\d]/g, "");
    if (!/^\d{10,11}$/.test(apenasNumeros)) return false;

    const ddd = apenasNumeros.substring(0, 2);
    if (parseInt(ddd) < 11 || parseInt(ddd) > 99) return false;

    if (apenasNumeros.length === 11 && apenasNumeros[2] !== "9") return false;

    return true;
  }

  // 🔹 Máscara automática de telefone
  function aplicarMascaraTelefone(input) {
    input.addEventListener("input", () => {
      let valor = input.value.replace(/\D/g, "");
      if (valor.length > 11) valor = valor.slice(0, 11);

      if (valor.length > 6) {
        input.value = `(${valor.slice(0, 2)}) ${valor.slice(2, 7)}-${valor.slice(7)}`;
      } else if (valor.length > 2) {
        input.value = `(${valor.slice(0, 2)}) ${valor.slice(2)}`;
      } else {
        input.value = valor;
      }
    });
  }

  // 🔹 Máscara automática de CPF
  function aplicarMascaraCPF(input) {
    input.addEventListener("input", () => {
      let valor = input.value.replace(/\D/g, ""); // remove tudo que não for número
      if (valor.length > 11) valor = valor.slice(0, 11);

      // Formata: 123.456.789-09
      if (valor.length > 9) {
        input.value = valor.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, "$1.$2.$3-$4");
      } else if (valor.length > 6) {
        input.value = valor.replace(/(\d{3})(\d{3})(\d{0,3})/, "$1.$2.$3");
      } else if (valor.length > 3) {
        input.value = valor.replace(/(\d{3})(\d{0,3})/, "$1.$2");
      } else {
        input.value = valor;
      }
    });
  }

  // Aplica máscaras nos campos
  const telefoneInput = document.querySelector("input[name='telefone']");
  const cpfInput = document.querySelector("input[name='cpf']");
  if (telefoneInput) aplicarMascaraTelefone(telefoneInput);
  if (cpfInput) aplicarMascaraCPF(cpfInput);

  // 🔹 Função para carregar pacientes
  async function carregarPacientes() {
    try {
      const res = await fetch("http://localhost:3000/api/pacientes");
      const pacientes = await res.json();

      tabela.innerHTML = "";

      if (pacientes.length === 0) {
        tabela.innerHTML = `<tr><td colspan="3" class="text-muted small">Nenhum paciente cadastrado</td></tr>`;
        return;
      }

      pacientes.forEach(p => {
        tabela.innerHTML += `
          <tr>
            <td>${p.nome}</td>
            <td>${p.cpf || "-"}</td>
            <td>${p.telefone || "-"}</td>
          </tr>
        `;
      });
    } catch (err) {
      console.error("Erro ao carregar pacientes:", err);
      tabela.innerHTML = `<tr><td colspan="3" class="text-danger">Erro ao buscar pacientes</td></tr>`;
    }
  }

  // 🔹 Envio do formulário
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const nome = form.nome.value.trim();
    const cpf = form.cpf.value.trim();
    const telefone = form.telefone.value.trim();
    const data_nascimento = form.data_nascimento.value;
    const endereco = form.endereco.value.trim();

    if (!nome) {
      alert("Por favor, preencha o nome do paciente.");
      return;
    }

    // ✅ Validação CPF
    if (cpf) {
      const cpfNumeros = cpf.replace(/[^\d]/g, "");
      if (cpfNumeros.length !== 11) {
        alert("⚠️ O CPF deve conter 11 dígitos numéricos.");
        return;
      }
      if (!validarCPF(cpfNumeros)) {
        alert("❌ CPF inválido! Verifique e tente novamente.");
        return;
      }
    }

    // ✅ Validação telefone
    if (telefone && !validarTelefone(telefone)) {
      alert("⚠️ Telefone inválido! Use formato (DD) 9XXXX-XXXX ou (DD) XXXX-XXXX.");
      return;
    }

    try {
      const res = await fetch("http://localhost:3000/api/pacientes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, cpf, telefone, data_nascimento, endereco }),
      });

      const resultado = await res.json();

      if (res.ok) {
        alert("✅ Paciente cadastrado com sucesso!");
        form.reset();
        carregarPacientes();
      } else {
        alert(`⚠️ Erro: ${resultado.error || "Falha ao cadastrar paciente."}`);
      }
    } catch (err) {
      console.error("Erro ao cadastrar paciente:", err);
      alert("❌ Erro de comunicação com o servidor.");
    }
  });

  // 🔹 Inicialização
  carregarPacientes();
});
