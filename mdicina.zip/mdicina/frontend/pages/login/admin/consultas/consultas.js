// script.js - Agendamento de Consultas e Controle de Login
document.addEventListener("DOMContentLoaded", async () => {
  const form = document.querySelector("form");
  const selectPaciente = document.querySelector("select[name='paciente_id']");
  const selectMedico = document.querySelector("select[name='medico_id']");
  const tabelaConsultas = document.querySelector("tbody");

  // 🔹 Função para obter o usuário logado
  function getUsuarioLogado() {
    const user =
      JSON.parse(localStorage.getItem("user")) ||
      JSON.parse(localStorage.getItem("usuario")) ||
      JSON.parse(localStorage.getItem("admin"));
    return user;
  }

  // 🔹 Verifica se há login ativo
  const user = getUsuarioLogado();
  if (!user) {
    alert("⚠️ Faça login para acessar o sistema.");
    window.location.href = "../login/views_login.html";
    return;
  }

  // 🔹 Mostra o nome do usuário no topo
  const nomeEl = document.getElementById("nomeUsuario");
  if (nomeEl) nomeEl.textContent = user.nome || "Usuário";

  // 🔹 Botão de logout
  const logoutBtn = document.getElementById("btnLogout");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("user");
      localStorage.removeItem("usuario");
      localStorage.removeItem("admin");
      window.location.href = "../login/views_login.html";
    });
  }

  // 🔹 Função para carregar pacientes
  async function carregarPacientes() {
    try {
      const res = await fetch("http://localhost:3000/api/pacientes");
      const pacientes = await res.json();
      selectPaciente.innerHTML = `<option value="">Selecione</option>`;
      pacientes.forEach(p => {
        selectPaciente.innerHTML += `<option value="${p.id}">${p.nome}</option>`;
      });
    } catch (err) {
      console.error("Erro ao carregar pacientes:", err);
    }
  }

  // 🔹 Função para carregar médicos
  async function carregarMedicos() {
    try {
      const res = await fetch("http://localhost:3000/api/medicos");
      const medicos = await res.json();
      selectMedico.innerHTML = `<option value="">Selecione</option>`;
      medicos.forEach(m => {
        selectMedico.innerHTML += `<option value="${m.id}">${m.nome}</option>`;
      });
    } catch (err) {
      console.error("Erro ao carregar médicos:", err);
    }
  }

  // 🔹 Função para carregar consultas agendadas
  async function carregarConsultas() {
    try {
      const res = await fetch("http://localhost:3000/api/consultas");
      const consultas = await res.json();

      if (!Array.isArray(consultas) || consultas.length === 0) {
        tabelaConsultas.innerHTML = `<tr><td colspan="4" class="text-muted small">Nenhum agendamento encontrado</td></tr>`;
        return;
      }

      tabelaConsultas.innerHTML = "";
      consultas.forEach(c => {
        tabelaConsultas.innerHTML += `
          <tr>
            <td>${new Date(c.data).toLocaleDateString("pt-BR")}</td>
            <td>${c.horario}</td>
            <td>${c.medico}</td>
            <td>${c.paciente}</td>
          </tr>`;
      });
    } catch (err) {
      console.error("Erro ao carregar consultas:", err);
    }
  }

  // 🔹 Envio do formulário de agendamento
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const paciente_id = selectPaciente.value;
    const medico_id = selectMedico.value;
    const data = form.data.value;
    const horario = form.horario.value;

    if (!paciente_id || !medico_id || !data || !horario) {
      alert("Por favor, preencha todos os campos!");
      return;
    }

    try {
      const res = await fetch("http://localhost:3000/api/consultas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paciente_id, medico_id, data, horario })
      });

      const result = await res.json();

      if (res.ok) {
        alert("✅ Consulta agendada com sucesso!");
        form.reset();
        carregarConsultas();
      } else {
        alert(`⚠️ Erro: ${result.error || "Não foi possível agendar"}`);
      }
    } catch (err) {
      console.error("Erro ao agendar consulta:", err);
      alert("❌ Falha na comunicação com o servidor.");
    }
  });

  // 🔹 Inicialização
  await carregarPacientes();
  await carregarMedicos();
  await carregarConsultas();
});
