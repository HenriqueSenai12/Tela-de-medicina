// script.js - Cadastro e listagem de médicos
document.addEventListener("DOMContentLoaded", async () => {
  const form = document.querySelector("form");
  const tabela = document.querySelector("tbody");

  // 🔹 Função para carregar os médicos do banco
  async function carregarMedicos() {
    try {
      const res = await fetch("http://localhost:3000/api/medicos");
      const medicos = await res.json();

      // Limpa a tabela antes de preencher
      tabela.innerHTML = "";

      if (medicos.length === 0) {
        tabela.innerHTML = `<tr><td colspan="3" class="text-muted small">Nenhum médico cadastrado</td></tr>`;
        return;
      }

      medicos.forEach(medico => {
        tabela.innerHTML += `
          <tr>
            <td>${medico.nome}</td>
            <td>${medico.especialidade || "-"}</td>
            <td>${medico.crm || "-"}</td>
          </tr>`;
      });
    } catch (erro) {
      console.error("Erro ao carregar médicos:", erro);
      tabela.innerHTML = `<tr><td colspan="3" class="text-danger">Erro ao carregar médicos</td></tr>`;
    }
  }

  // 🔹 Evento de envio do formulário de cadastro
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const nome = form.nome.value.trim();
    const especialidade = form.especialidade.value.trim();
    const crm = form.crm.value.trim();
    const horario_atendimento = form.horario_atendimento.value.trim();

    if (!nome) {
      alert("Por favor, preencha o nome do médico.");
      return;
    }

    try {
      const res = await fetch("http://localhost:3000/api/medicos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, especialidade, crm, horario_atendimento })
      });

      const resultado = await res.json();

      if (res.ok) {
        alert("✅ Médico cadastrado com sucesso!");
        form.reset();
        carregarMedicos();
      } else {
        alert(`⚠️ Erro: ${resultado.error || "Falha ao cadastrar médico."}`);
      }
    } catch (erro) {
      console.error("Erro ao cadastrar médico:", erro);
      alert("❌ Falha na comunicação com o servidor.");
    }
  });

  // 🔹 Inicialização
  carregarMedicos();
});
