async function carregarFuncionarios() {
  try {
    const res = await fetch("http://localhost:3000/api/users");
    if (!res.ok) throw new Error("Erro ao carregar funcionários");

    const funcionarios = await res.json();
    console.log(funcionarios);

    // Exemplo: renderizar na tabela
    const tabela = document.getElementById("tabela-funcionarios");
    tabela.innerHTML = funcionarios.map(f => `
      <tr>
        <td>${f.nome}</td>
        <td>${f.email}</td>
        <td>${f.idade ?? "-"}</td>
        <td>${f.cargo_legivel}</td>
        <td>
          <button class="btn btn-warning btn-sm" onclick="editarFuncionario(${f.id})">Editar</button>
          <button class="btn btn-danger btn-sm" onclick="excluirFuncionario(${f.id})">Excluir</button>
        </td>
      </tr>
    `).join("");

  } catch (err) {
    console.error(err);
    alert("Erro ao carregar lista de funcionários");
  }
}

// Chama ao carregar página:
carregarFuncionarios();
