// Dashboard front-end: lista consultas, modifica e exclui (conectado com /api/consultas)

document.addEventListener("DOMContentLoaded", async () => {
  const totalConsultasEl = document.querySelector(".bg-1 h2");
  const totalPacientesEl = document.querySelector(".bg-2 h2");
  const listaMedicosEl = document.querySelector(".bg-3 ul");
  const tabelaBody = document.querySelector("tbody");
  const saudacaoEl = document.querySelector("p strong");
  const dataHojeEl = document.querySelector("small");

  // Modal e campos
  const editarModalEl = document.getElementById("editarModal");
  const editarModal = new bootstrap.Modal(editarModalEl);
  const formEditar = document.getElementById("formEditar");
  const inputConsultaId = document.getElementById("editarConsultaId");
  const selectPaciente = document.getElementById("editarPaciente");
  const selectMedico = document.getElementById("editarMedico");
  const inputData = document.getElementById("editarData");
  const inputHorario = document.getElementById("editarHorario");
  const editarFeedback = document.getElementById("editarFeedback");

  // Função para obter usuário logado (mesma lógica que já havia)
  function getUsuarioLogado() {
    return (
      JSON.parse(localStorage.getItem("user")) ||
      JSON.parse(localStorage.getItem("usuario")) ||
      JSON.parse(localStorage.getItem("admin"))
    );
  }

  const user = getUsuarioLogado();
  if (!user) {
    alert("⚠️ Faça login para acessar o sistema.");
    window.location.href = "../login/views_login.html";
    return;
  }

  // Mostra nome e data atual
  const hojeStr = new Date().toLocaleDateString("pt-BR");
  dataHojeEl.textContent = hojeStr;
  saudacaoEl.textContent = user.nome || "Usuário";

  // Carrega médicos e pacientes para selects
  async function fetchPacientes() {
    const res = await fetch("http://localhost:3000/api/pacientes");
    return await res.json();
  }

  async function fetchMedicos() {
    const res = await fetch("http://localhost:3000/api/medicos");
    return await res.json();
  }

  // Carrega dashboard (consultas, totais, tabela)
  async function carregarDashboard() {
    try {
      const consultasRes = await fetch("http://localhost:3000/api/consultas");
      const consultas = await consultasRes.json();

      const pacientes = await fetchPacientes();
      const medicos = await fetchMedicos();

      totalPacientesEl.textContent = pacientes.length || 0;

      // Total de consultas do dia (comparar com YYYY-MM-DD)
      const hojeISO = new Date().toISOString().split("T")[0];
      const consultasHoje = consultas.filter((c) => c.data && c.data.startsWith(hojeISO));
      totalConsultasEl.textContent = consultasHoje.length;

      // Agrupar consultas por médico
      const medicosMap = {};
      consultas.forEach((c) => {
        const nomeMed = c.medico || "Sem nome";
        if (!medicosMap[nomeMed]) medicosMap[nomeMed] = { especialidade: c.especialidade || "", total: 0 };
        medicosMap[nomeMed].total++;
      });

      // Exibir lista de médicos
      listaMedicosEl.innerHTML = "";
      const nomesMedicos = Object.keys(medicosMap);
      if (nomesMedicos.length === 0) {
        listaMedicosEl.innerHTML = `<li class="small-muted">Nenhum dado</li>`;
      } else {
        nomesMedicos.forEach((nome) => {
          const info = medicosMap[nome];
          listaMedicosEl.innerHTML += `<li><strong>${nome}</strong> (${info.especialidade}) — ${info.total} consultas</li>`;
        });
      }

      // Preenche tabela com botões de Ações
      tabelaBody.innerHTML = "";
      if (!consultas.length) {
        tabelaBody.innerHTML = `<tr><td colspan="5" class="small-muted">Nenhum agendamento encontrado</td></tr>`;
      } else {
        consultas.forEach((c) => {
          tabelaBody.innerHTML += `
            <tr data-id="${c.id}">
              <td>${c.horario || "-"}</td>
              <td>${c.medico || "-"}</td>
              <td>${c.paciente || "-"}</td>
              <td>${c.data ? new Date(c.data).toLocaleDateString("pt-BR") : "-"}</td>
              <td>
                <div class="d-flex gap-2">
                  <button class="btn btn-sm btn-outline-primary btn-modificar" data-id="${c.id}">
                    <i class="bi bi-pencil-square"></i> Modificar
                  </button>
                  <button class="btn btn-sm btn-outline-danger btn-cancelar" data-id="${c.id}">
                    <i class="bi bi-x-circle"></i> Cancelar
                  </button>
                </div>
              </td>
            </tr>
          `;
        });
      }

      // Associa eventos aos botões (depois de criar a tabela)
      document.querySelectorAll(".btn-cancelar").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.getAttribute("data-id");
          if (!confirm("Deseja realmente cancelar esta consulta?")) return;
          await cancelarConsulta(id);
        });
      });

      document.querySelectorAll(".btn-modificar").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.getAttribute("data-id");
          abrirModalEditar(id, pacientes, medicos);
        });
      });

    } catch (err) {
      console.error("Erro ao carregar dashboard:", err);
      alert("❌ Erro ao buscar dados do servidor.");
    }
  }

  // Cancelar consulta (DELETE)
  async function cancelarConsulta(id) {
    try {
      const res = await fetch(`http://localhost:3000/api/consultas/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.json();
        alert(`Erro: ${err.error || res.statusText}`);
        return;
      }
      alert("✅ Consulta cancelada com sucesso.");
      await carregarDashboard();
    } catch (err) {
      console.error(err);
      alert("Erro ao cancelar consulta.");
    }
  }

  // Abrir modal de edição: recebe id e listas já carregadas de pacientes/medicos (para evitar múltiplas requests)
  async function abrirModalEditar(id, pacientesList = null, medicosList = null) {
    try {
      // se não foram passadas, busca
      const [pacientes, medicos] = await Promise.all([
        pacientesList ? Promise.resolve(pacientesList) : fetchPacientes(),
        medicosList ? Promise.resolve(medicosList) : fetchMedicos(),
      ]);

      // Preenche selects
      selectPaciente.innerHTML = pacientes.map(p => `<option value="${p.id}">${p.nome}</option>`).join("");
      selectMedico.innerHTML = medicos.map(m => `<option value="${m.id}">${m.nome} (${m.especialidade || ''})</option>`).join("");

      // Busca a consulta por id (rota GET /api/consultas/:id)
      const res = await fetch(`http://localhost:3000/api/consultas/${id}`);
      if (!res.ok) {
        const err = await res.json();
        alert(`Erro: ${err.error || res.statusText}`);
        return;
      }
      const consulta = await res.json();

      // Preenche campos do modal
      inputConsultaId.value = consulta.id;
      // data no formato YYYY-MM-DD
      if (consulta.data) {
        const d = new Date(consulta.data);
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, "0");
        const dd = String(d.getDate()).padStart(2, "0");
        inputData.value = `${yyyy}-${mm}-${dd}`;
      } else {
        inputData.value = "";
      }
      // horário - tenta converter se estiver no formato "HH:MM:SS" ou "HH:MM"
      inputHorario.value = consulta.horario ? consulta.horario.slice(0,5) : "";

      // Seleciona paciente e médico pelos ids retornados
      if (consulta.paciente_id) selectPaciente.value = consulta.paciente_id;
      if (consulta.medico_id) selectMedico.value = consulta.medico_id;

      editarFeedback.textContent = "";
      editarModal.show();
    } catch (err) {
      console.error(err);
      alert("Erro ao abrir modal de edição.");
    }
  }

  // Salvar edição (PUT)
  formEditar.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const id = inputConsultaId.value;
    const paciente_id = selectPaciente.value;
    const medico_id = selectMedico.value;
    const data = inputData.value; // YYYY-MM-DD
    let horario = inputHorario.value; // HH:MM

    if (!paciente_id || !medico_id || !data || !horario) {
      editarFeedback.textContent = "Preencha todos os campos.";
      return;
    }

    // Formata horario para HH:MM:SS (opcional)
    if (horario.length === 5) horario = horario + ":00";

    try {
      const res = await fetch(`http://localhost:3000/api/consultas/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paciente_id, medico_id, data, horario })
      });

      if (res.status === 409) {
        const err = await res.json();
        editarFeedback.textContent = err.error || "Conflito de horário.";
        return;
      }

      if (!res.ok) {
        const err = await res.json();
        editarFeedback.textContent = err.error || "Erro ao atualizar.";
        return;
      }

      // sucesso
      editarFeedback.textContent = "";
      editarModal.hide();
      alert("✅ Consulta atualizada com sucesso.");
      await carregarDashboard();
    } catch (err) {
      console.error(err);
      editarFeedback.textContent = "Erro de comunicação com o servidor.";
    }
  });

  // Inicial
  await carregarDashboard();

  // Logout (se existir botão)
  const logoutBtn = document.getElementById("btnLogout");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("user");
      localStorage.removeItem("usuario");
      localStorage.removeItem("admin");
      window.location.href = "../login/views_login.html";
    });
  }
});// ... (mantém o resto do arquivo) ...

// Abrir modal de edição: recebe id e listas já carregadas de pacientes/medicos (para evitar múltiplas requests)
async function abrirModalEditar(id, pacientesList = null, medicosList = null) {
  try {
    // se não foram passadas, busca
    const [pacientes, medicos] = await Promise.all([
      pacientesList ? Promise.resolve(pacientesList) : fetchPacientes(),
      medicosList ? Promise.resolve(medicosList) : fetchMedicos(),
    ]);

    // Preenche selects
    selectPaciente.innerHTML = pacientes.map(p => `<option value="${p.id}">${p.nome}</option>`).join("");
    selectMedico.innerHTML = medicos.map(m => `<option value="${m.id}">${m.nome} (${m.especialidade || ''})</option>`).join("");

    // Busca a consulta por id (rota GET /api/consultas/:id)
    const res = await fetch(`http://localhost:3000/api/consultas/${id}`);

    // Se não OK, tenta ler JSON ou texto para exibir mensagem amigável
    if (!res.ok) {
      const contentType = res.headers.get('content-type') || '';
      let body;
      if (contentType.includes('application/json')) {
        body = await res.json();
        alert(`Erro ao buscar consulta: ${body.error || res.statusText} (status ${res.status})`);
      } else {
        // resposta não-JSON (HTML provavelmente) -> mostra trecho para debugging
        const text = await res.text();
        console.error('Resposta inesperada do servidor:', text.slice(0, 1000));
        alert(`Erro inesperado do servidor (status ${res.status}). Veja console para detalhes.`);
      }
      return;
    }

    // Se OK, mas confirme content-type antes
    const contentType = res.headers.get('content-type') || '';
    let consulta;
    if (contentType.includes('application/json')) {
      consulta = await res.json();
    } else {
      // resposta inesperada (por segurança)
      const text = await res.text();
      console.error('Resposta inesperada ao buscar consulta (esperava JSON):', text.slice(0, 1000));
      alert('Resposta inesperada do servidor. Veja console para detalhes.');
      return;
    }

    // Preenche campos do modal
    inputConsultaId.value = consulta.id;
    if (consulta.data) {
      const d = new Date(consulta.data);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      inputData.value = `${yyyy}-${mm}-${dd}`;
    } else {
      inputData.value = "";
    }
    inputHorario.value = consulta.horario ? consulta.horario.slice(0,5) : "";

    if (consulta.paciente_id) selectPaciente.value = consulta.paciente_id;
    if (consulta.medico_id) selectMedico.value = consulta.medico_id;

    editarFeedback.textContent = "";
    editarModal.show();
  } catch (err) {
    console.error(err);
    alert("Erro ao abrir modal de edição.");
  }
}