const express = require('express');
const cors = require('cors');
require('dotenv').config();


const usersRouter = require('./routes/users');
const pacientesRouter = require('./routes/pacientes');
const medicosRouter = require('./routes/medicos');
const consultasRouter = require('./routes/consultas');


const app = express();
app.use(cors());
app.use(express.json());


app.use('/api/users', usersRouter);
app.use('/api/pacientes', pacientesRouter);
app.use('/api/medicos', medicosRouter);
app.use('/api/consultas', consultasRouter);




app.get('/', (req, res) => res.send('API Agenda Médica - OK'));


const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Servidor rodando na porta ${port}`));