const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const pool = require('../db');


// Registrar usuário (somente admin exemplificado)
router.post('/register', async (req, res) => {
try {
const { nome, email, senha, tipo } = req.body;
if (!nome || !email || !senha) return res.status(400).json({ error: 'Campos obrigatórios' });


const [exists] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
if (exists.length) return res.status(400).json({ error: 'Email já cadastrado' });


const hash = await bcrypt.hash(senha, 10);
const [result] = await pool.query('INSERT INTO users (nome, email, senha, tipo) VALUES (?, ?, ?, ?)', [nome, email, hash, tipo || 'recepcao']);
res.status(201).json({ id: result.insertId, nome, email });
} catch (err) {
console.error(err);
res.status(500).json({ error: 'Erro no servidor' });
}
});


// Login simples (retorna usuário sem token para didática)
router.post('/login', async (req, res) => {
try {
const { email, senha } = req.body;
if (!email || !senha) return res.status(400).json({ error: 'Campos obrigatórios' });


const [rows] = await pool.query('SELECT id, nome, email, senha, tipo FROM users WHERE email = ?', [email]);
if (!rows.length) return res.status(400).json({ error: 'Usuário não encontrado' });


const user = rows[0];
const match = await bcrypt.compare(senha, user.senha);
if (!match) return res.status(401).json({ error: 'Senha incorreta e/ou e-mail incorreto' });


// Para simplicidade, retornamos os dados do usuário (não recomendamos em produção sem token)
delete user.senha;
res.json({ user });
} catch (err) {
console.error(err);
res.status(500).json({ error: 'Erro no servidor' });
}
});


module.exports = router;