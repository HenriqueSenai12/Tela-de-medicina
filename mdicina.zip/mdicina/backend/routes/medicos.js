const express = require('express');
const router = express.Router();
const pool = require('../db');


// Criar médico
router.post('/', async (req, res) => {
    try {
        const { nome, especialidade, crm, horario_atendimento } = req.body;
        const [result] = await pool.query(
            'INSERT INTO medicos (nome, especialidade, crm, horario_atendimento) VALUES (?, ?, ?, ?)',
            [nome, especialidade, crm, horario_atendimento]
        );
        res.status(201).json({ id: result.insertId, nome });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao criar médico' });
    }
});


// Listar
router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM medicos ORDER BY nome');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao listar médicos' });
    }
});


// Buscar por id
router.get('/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM medicos WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ error: 'Médico não encontrado' });
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro no servidor' });
    }
});


// Atualizar
router.put('/:id', async (req, res) => {
    try {
        const { nome, especialidade, crm, horario_atendimento } = req.body;
        await pool.query(
            'UPDATE medicos SET nome = ?, especialidade = ?, crm = ?, horario_atendimento = ? WHERE id = ?',
            [nome, especialidade, crm, horario_atendimento, req.params.id]
        );
        res.json({ message: 'Médico atualizado' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao atualizar médico' });
    }
});


// Deletar
router.delete('/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM medicos WHERE id = ?', [req.params.id]);
        res.json({ message: 'Médico removido' });
    } catch (err) {
        console.error(err);
    }
})


module.exports = router;
// 🔹 Rota para listar cada médico com seus pacientes
